import { NextResponse } from 'next/server'

const FINNHUB = 'd0imh21r01qrfsah3gn0d0imh21r01qrfsah3gng'

const MEM = {}
const ONE_HOUR = 60 * 60 * 1000

export const dynamic = 'force-dynamic'

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const symbol = searchParams.get('symbol')
  if (!symbol) return NextResponse.json({ error: 'Symbol required' }, { status: 400 })

  const sym = symbol.toUpperCase()
  const cached = MEM[sym]
  if (cached && Date.now() - cached.ts < ONE_HOUR) {
    return NextResponse.json({ prices: cached.prices, source: 'cache' })
  }

  // Strategy 1: Finnhub candles — free tier, no encoding issues, 1yr history
  try {
    const to   = Math.floor(Date.now() / 1000)
    const from = to - 365 * 24 * 60 * 60

    const r = await fetch(
      `https://finnhub.io/api/v1/stock/candle?symbol=${sym}&resolution=D&from=${from}&to=${to}&token=${FINNHUB}`
    )
    if (!r.ok) throw new Error(`Finnhub ${r.status}`)
    const d = await r.json()
    if (d.s !== 'ok' || !d.c?.length) throw new Error('No candle data from Finnhub')

    const prices = d.t.map((ts, i) => ({
      date:   new Date(ts * 1000).toISOString().split('T')[0],
      value:  d.c[i],
      close:  d.c[i],
      open:   d.o[i],
      high:   d.h[i],
      low:    d.l[i],
      volume: d.v[i],
    }))

    MEM[sym] = { prices, ts: Date.now() }
    return NextResponse.json({ prices, source: 'finnhub' })
  } catch (e) {
    console.log(`[daily] Finnhub failed for ${sym}:`, e.message)
  }

  // Strategy 2: yahoo-finance2 fallback
  try {
    const yahooFinance = require('yahoo-finance2').default
    const raw = await yahooFinance.historical(sym, {
      period1: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000),
      period2: new Date(),
      interval: '1d',
    })
    if (!raw?.length) throw new Error('No Yahoo data')
    const prices = raw.map(c => ({
      date:   c.date.toISOString().split('T')[0],
      value:  c.close,
      close:  c.close,
      open:   c.open,
      high:   c.high,
      low:    c.low,
      volume: c.volume || 0,
    }))
    MEM[sym] = { prices, ts: Date.now() }
    return NextResponse.json({ prices, source: 'yahoo' })
  } catch (e) {
    console.log(`[daily] Yahoo failed for ${sym}:`, e.message)
  }

  return NextResponse.json({ prices: [], error: 'All providers failed' }, { status: 500 })
}