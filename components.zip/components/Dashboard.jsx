'use client'
import { useState, useEffect, useCallback, useRef } from 'react'
import { useAuth } from '../app/hooks/useAuth'
import AccountMenu from './AccountMenu'
import { C } from './dash/dashTheme'
import DashSearch    from './dash/DashSearch'
import PageHome      from './dash/PageHome'
import PageQuote     from './dash/PageQuote'
import PageNews      from './dash/PageNews'
import PageScreener  from './dash/PageScreener'
import PageCharts    from './dash/PageCharts'
import PageMaps      from './dash/PageMaps'
import PageGroups    from './dash/PageGroups'
import PagePortfolio from './dash/PagePortfolio'
import PageInsider   from './dash/PageInsider'
import PageFutures   from './dash/PageFutures'
import PageForex     from './dash/PageForex'
import PageCrypto    from './dash/PageCrypto'
import PageCalendar  from './dash/PageCalendar'
import PageBacktests from './dash/PageBacktests'
import PagePricing   from './dash/PagePricing'

const NAV = ['Home','News','Screener','Charts','Maps','Groups','Portfolio','Insider','Futures','Forex','Crypto','Calendar','Backtests','Pricing']

function NavLink({ label, active, onClick, borderLeft }) {
  const [hov, setHov] = useState(false)
  return (
    <a href="#" onClick={e=>{e.preventDefault();onClick()}} style={{
      display:'flex',alignItems:'center',padding:'0 7px',height:30,
      fontSize:13,fontWeight:700,whiteSpace:'nowrap',fontFamily:C.fnt,
      textDecoration:'none',flexShrink:0,boxSizing:'border-box',
      color:active||hov?'#fff':C.navTxt,
      background:active||hov?C.navHov:'transparent',
      borderBottom:active?'2px solid #4fa4f4':'2px solid transparent',
      borderLeft:borderLeft?'1px solid #444a57':'none',
    }} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      {label}
    </a>
  )
}

function PromoBanner() {
  const [on, setOn] = useState(true)
  if (!on) return null
  return (
    <div style={{background:'#5e36b8',display:'flex',justifyContent:'center',alignItems:'center',gap:10,padding:'0 16px',height:40,flexShrink:0}}>
      <p style={{color:'#ede9fe',fontSize:13,margin:0}}>
        <b style={{color:'#fff'}}>New:</b> Analyst ratings now visible directly on CompoundPulse charts.
      </p>
      <span style={{color:'#c4b5fd',fontSize:22,cursor:'pointer',lineHeight:1,marginLeft:8}} onClick={()=>setOn(false)}>×</span>
    </div>
  )
}

export default function Dashboard() {
  const { user } = useAuth()
  const [nav, setNav]   = useState('Home')
  const [quote, setQuote] = useState(null)
  const [time, setTime] = useState('')

  useEffect(()=>{
    const tick=()=>setTime(new Date().toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit',hour12:true}))
    tick(); const id=setInterval(tick,30000); return ()=>clearInterval(id)
  },[])

  const goTicker = useCallback(t=>{ setQuote(t.toUpperCase()); setNav('Quote') },[])
  const goNav    = useCallback(n=>{ setNav(n); setQuote(null) },[])

  // All pages live in a stable ref — created once, never recreated
  const pagesRef = useRef(null)
  if (!pagesRef.current) {
    pagesRef.current = {
      Home:      <PageHome      onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      News:      <PageNews      onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Screener:  <PageScreener  onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Charts:    <PageCharts/>,
      Maps:      <PageMaps      onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Groups:    <PageGroups/>,
      Portfolio: <PagePortfolio onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Insider:   <PageInsider   onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Futures:   <PageFutures/>,
      Forex:     <PageForex/>,
      Crypto:    <PageCrypto    onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Calendar:  <PageCalendar  onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Backtests: <PageBacktests onT={t=>{ setQuote(t.toUpperCase()); setNav('Quote') }}/>,
      Pricing:   <PagePricing/>,
    }
  }

  const active = quote ? 'Home' : nav

  return (
    <div style={{background:'#14161d',fontFamily:C.fnt,color:'#d1d4dc',fontSize:13,minHeight:'100vh',display:'flex',flexDirection:'column'}}>

      {/* HEADER */}
      <div style={{background:'#22262f',borderBottom:'1px solid #4c5263',padding:'8px 10px',display:'flex',alignItems:'center',gap:16,flexShrink:0}}>
        <a href="#" onClick={e=>{e.preventDefault();goNav('Home')}} style={{textDecoration:'none',flexShrink:0}}>
          <span style={{fontSize:22,fontWeight:900,color:'#363a46',fontFamily:C.fnt}}>Compound</span>
          <span style={{fontSize:22,fontWeight:900,color:'#4fa4f4',fontFamily:C.fnt}}>Pulse</span>
        </a>
        <DashSearch onT={goTicker}/>
        <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:12,flexShrink:0}}>
          <span style={{fontSize:11,color:'#868ea5',whiteSpace:'nowrap'}}>{time}</span>
          {user && <AccountMenu/>}
        </div>
      </div>

      {/* NAVBAR */}
      <div style={{background:C.navBg,height:30,display:'flex',alignItems:'stretch',overflowX:'auto',overflowY:'hidden',boxShadow:'0 1px 3px rgba(0,0,0,.15)',flexShrink:0}}>
        {NAV.map(n=><NavLink key={n} label={n} active={active===n} onClick={()=>goNav(n)}/>)}
        <div style={{flex:1}}/>
        {['Help','Login','Register'].map((n,i)=><NavLink key={n} label={n} active={false} onClick={()=>{}} borderLeft={i===0}/>)}
      </div>

      <PromoBanner/>

      {/* CONTENT — pages hidden with display:none, never unmounted = no scroll reset */}
      <div style={{flex:1,width:'95%',maxWidth:1425,margin:'0 auto',minWidth:0,background:'#14161d'}}>

        {/* Quote page — keyed by ticker so it remounts only when ticker changes */}
        <div style={{display: quote ? 'block' : 'none'}}>
          {quote && <PageQuote key={quote} ticker={quote} onBack={()=>{setQuote(null);setNav('Home')}}/>}
        </div>

        {/* All other pages — permanently in DOM, toggled with display */}
        {Object.entries(pagesRef.current).map(([key, el])=>(
          <div key={key} style={{display: !quote && nav===key ? 'block' : 'none'}}>
            {el}
          </div>
        ))}

        {/* Fallback for Backtests/Pricing */}
        {!quote && !pagesRef.current[nav] && (
          <div style={{padding:80,textAlign:'center',color:C.txt,fontSize:14,fontFamily:C.fnt}}>
            <div style={{fontSize:20,fontWeight:700,marginBottom:8,color:'#000'}}>{nav}</div>
            Coming soon
          </div>
        )}
      </div>

      <div style={{background:'#22262f',borderTop:'1px solid #4c5263',padding:'6px 16px',fontSize:10,color:'#868ea5',textAlign:'center',flexShrink:0}}>
        © 2026 CompoundPulse · Market data delayed 15 min · Not financial advice
      </div>
    </div>
  )
}