'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'
import { Spark } from './dashAtoms'

function FxRow({ r, i }) {
  const [hov, setHov] = useState(false)
  const pos  = r.changePercent == null || parseFloat(r.changePercent) >= 0
  const seed = r.pair.charCodeAt(0)*3 + i*7
  // Format: show enough decimals for forex (4 for most, 2 for JPY crosses)
  const isJPY = r.pair.includes('JPY') || r.pair.includes('CNY')
  const fmtPrice = v => v != null ? parseFloat(v).toFixed(isJPY ? 3 : 4) : '—'

  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'5px 8px',borderBottom:bd,fontWeight:700,color:C.link}}>{r.pair}</td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,color:'#000',fontFamily:'monospace',fontSize:13}}>
        {r.price != null ? fmtPrice(r.price) : <span style={{color:'#ccc',fontSize:10}}>…</span>}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:700,
        color:pos?C.pos:C.neg,whiteSpace:'nowrap'}}>
        {r.changePercent != null
          ? `${pos?'+':''}${parseFloat(r.changePercent).toFixed(4)}%`
          : <span style={{color:'#ccc',fontSize:10}}>…</span>}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontSize:11,color:'#999'}}>
        {r.high != null ? `H: ${fmtPrice(r.high)}` : ''}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontSize:11,color:'#999'}}>
        {r.low != null ? `L: ${fmtPrice(r.low)}` : ''}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right'}}>
        {r.price && <Spark pos={pos} seed={seed}/>}
      </td>
    </tr>
  )
}

export default function PageForex() {
  const [rates,   setRates]   = useState([])
  const [loading, setLoading] = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    fetch('/api/forex-rates')
      .then(r => r.ok ? r.json() : [])
      .then(d => { setRates(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Forex</span>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>
          {loading ? 'Loading rates…' : 'OANDA via Finnhub · cached 15min'}
        </span>
      </div>
      {loading && <div style={{padding:40,textAlign:'center',color:C.txt}}>Loading…</div>}
      {!loading && (
        <table style={{width:'100%',maxWidth:600,borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
          <thead><tr>
            <th style={thS()}>Pair</th>
            <th style={thS(true)}>Rate</th>
            <th style={thS(true)}>Change</th>
            <th style={thS(true)}>High</th>
            <th style={thS(true)}>Low</th>
            <th style={thS(true)}>Daily</th>
          </tr></thead>
          <tbody>
            {rates.filter(r => r).map((r,i) => <FxRow key={r.pair} r={r} i={i}/>)}
            {rates.length === 0 && <tr><td colSpan={6} style={{padding:20,textAlign:'center',color:C.txt}}>No data</td></tr>}
          </tbody>
        </table>
      )}
      <div style={{marginTop:6,fontSize:10,color:'#bbb',fontFamily:C.fnt}}>Real forex rates via OANDA · Not for trading</div>
    </div>
  )
}