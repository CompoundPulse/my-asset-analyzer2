// dashTheme.js — CompoundPulse / TradingView exact dark theme

export const C = {
  // TradingView exact palette
  bg0:     '#131722',  // deepest background
  bg1:     '#1e222d',  // panels, sidebars
  bg2:     '#2a2e39',  // elevated elements, table headers
  bg3:     '#363a45',  // borders, hover states

  // Text
  txt:     '#d1d4dc',  // primary text
  txt2:    '#787b86',  // secondary / muted
  txt3:    '#4c525e',  // very muted

  // Accent / action
  link:    '#2962ff',  // links, accents
  linkHov: '#4c8bff',  // link hover

  // Bull / Bear
  pos:     '#26a69a',  // green / positive
  neg:     '#ef5350',  // red / negative
  posD:    'rgba(38,166,154,0.15)',
  negD:    'rgba(239,83,80,0.15)',

  // Nav (TradingView top bar style)
  navBg:   '#1e222d',
  navHov:  '#2a2e39',
  navTxt:  '#787b86',
  navAct:  '#d1d4dc',

  // Legacy aliases (keep other pages working)
  hdrBg:   '#2a2e39',
  alt:     '#1e222d',
  hov:     '#2a2e39',
  bdr:     '#363a45',
  thBg:    '#2a2e39',
  thBdr:   '#363a45',
  txt2old: '#787b86',

  fnt: "'Source Sans Pro',Arial,sans-serif",
}

export const bd = `1px solid ${C.bg3}`

export const thS = (right = false) => ({
  padding: right ? '4px 8px' : '4px 4px 4px 6px',
  fontSize: 11, fontWeight: 700, color: C.txt2,
  borderBottom: `1px solid ${C.bg3}`,
  textAlign: right ? 'right' : 'left',
  background: C.bg2, fontFamily: C.fnt, whiteSpace: 'nowrap',
})