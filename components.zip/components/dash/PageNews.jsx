'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'

function NewsRow({ r, i, onT }) {
  const [hov, setHov] = useState(false)
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'4px 8px',borderBottom:bd,whiteSpace:'nowrap',verticalAlign:'top',width:60}}>
        {r.t && <span style={{color:C.link,fontWeight:700,fontSize:12,cursor:'pointer'}} onClick={()=>onT(r.t)}>{r.t}</span>}
      </td>
      <td style={{padding:'4px 8px',borderBottom:bd,verticalAlign:'top'}}>
        <a href={r.url} target="_blank" rel="noopener noreferrer"
          style={{color:'#333',textDecoration:'none',fontSize:12,lineHeight:'16px'}}
          onMouseEnter={e=>e.currentTarget.style.textDecoration='underline'}
          onMouseLeave={e=>e.currentTarget.style.textDecoration='none'}>{r.h}</a>
      </td>
      <td style={{padding:'4px 8px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11,color:'#888',textAlign:'right',verticalAlign:'top'}}>{r.src}</td>
      <td style={{padding:'4px 6px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11,color:'#888',textAlign:'right',verticalAlign:'top'}}>{r.time}</td>
    </tr>
  )
}

export default function PageNews({ onT }) {
  const [news, setNews] = useState([])
  const [loading, setLoading] = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    fetch('/api/market-data?section=news')
      .then(r => r.ok ? r.json() : [])
      .then(data => { setNews(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Market News</span>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>
          {loading ? 'Loading…' : `${news.length} stories · Finnhub · cached 15min`}
        </span>
      </div>
      {loading && <div style={{padding:40,textAlign:'center',color:C.txt}}>Loading…</div>}
      {!loading && (
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
          <thead><tr>
            <th style={{...thS(),width:60}}>Ticker</th>
            <th style={thS()}>Headline</th>
            <th style={{...thS(true),width:90}}>Source</th>
            <th style={{...thS(true),width:70}}>Time</th>
          </tr></thead>
          <tbody>{news.map((r,i)=><NewsRow key={i} r={r} i={i} onT={onT}/>)}</tbody>
        </table>
      )}
    </div>
  )
}