'use client'
import { useState } from 'react'
import { C, bd } from './dashTheme'

const PLANS = [
  {
    name: 'Starter Trial',
    price: 0,
    period: '7 days',
    color: '#888',
    badge: 'No card needed',
    features: [
      'Full Pro access for 7 days',
      'Real-time quotes',
      'Screener + backtester',
      'Portfolio tracking',
      'Pattern detection',
      'Auto-upgrades to Pro after trial',
    ],
    cta: 'Start Free Trial',
    priceId: 'price_pro_monthly',
  },
  {
    name: 'Pro',
    price: 29,
    period: '/mo',
    color: C.link,
    badge: 'Most Popular',
    features: [
      'Real-time quotes',
      'Full screener + filters',
      'Portfolio tracking (Supabase sync)',
      'Strategy backtester',
      'Sector & group heatmaps',
      'Insider transaction data',
      'Forex & futures dashboard',
      'Unlimited watchlist',
      'Pattern detection (4H, 1D, 1W)',
    ],
    cta: 'Start Free Trial',
    priceId: 'price_pro_monthly',
  },
  {
    name: 'Pro Annual',
    price: 19,
    period: '/mo',
    color: '#7c3aed',
    badge: 'Save 35%',
    features: [
      'Everything in Pro',
      'Billed $228/year (save $120)',
      'Priority support',
      'Early access to new features',
      'Export data to CSV',
      'Multi-device sync',
    ],
    cta: 'Start Free Trial',
    priceId: 'price_pro_annual',
  },
  {
    name: 'Team',
    price: 79,
    period: '/mo',
    color: '#0f766e',
    features: [
      'Everything in Pro Annual',
      'Up to 5 team members',
      'Shared watchlists & alerts',
      'Team portfolio view',
      'Dedicated account manager',
      'Custom data exports',
      'API access (coming soon)',
    ],
    cta: 'Contact Sales',
    isTeam: true,
  },
]

const FAQ = [
  { q: 'Can I cancel anytime?', a: 'Yes. Cancel from your account settings at any time. You keep access until the end of your billing period.' },
  { q: 'Is there a free trial?', a: 'Yes — Pro and Pro Annual both include a 7-day free trial. No credit card required to start.' },
  { q: 'Where does the market data come from?', a: 'Quotes and fundamentals via Finnhub. Historical charts via Yahoo Finance. Forex via ExchangeRate-API (ECB reference rates). All data is for informational purposes only.' },
  { q: 'How does the backtester work?', a: 'We pull up to 1 year of daily price history and run your selected strategy rules (SMA crossover, RSI, Bollinger Bands, MACD, Momentum) against historical data. Results show hypothetical past performance only.' },
  { q: 'What is pattern detection?', a: 'Our algorithm scans price action for chart patterns (Bull Flag, Ascending Triangle, Rising Wedge, Support Test, etc.) across 4H, daily, and weekly timeframes with a confidence score.' },
]

export default function PagePricing() {
  const [faqOpen, setFaqOpen] = useState({})
  const [annual, setAnnual] = useState(false)

  const handleCTA = plan => {
    // no disabled plans
    if (plan.isTeam) { window.open('mailto:hello@compoundpulse.com?subject=Team Plan Inquiry','_blank'); return }
    window.location.href = `/api/stripe/create-checkout?priceId=${plan.priceId}`
  }

  return (
    <div style={{padding:'12px 0',maxWidth:900}}>
      <div style={{textAlign:'center',marginBottom:24,fontFamily:C.fnt}}>
        <div style={{fontSize:22,fontWeight:900,color:'#000',marginBottom:4}}>CompoundPulse Pricing</div>
        <div style={{fontSize:13,color:'#666'}}>Professional market intelligence · No ads · Cancel anytime</div>
      </div>

      <div style={{display:'flex',gap:12,flexWrap:'wrap',justifyContent:'center',marginBottom:32}}>
        {PLANS.map(plan => (
          <div key={plan.name} style={{
            width:200,border:`2px solid ${plan.color}`,borderRadius:8,
            padding:'20px 16px',fontFamily:C.fnt,position:'relative',
            background: plan.name==='Pro'?'#f0f4ff':'#fff',
            boxShadow: plan.name==='Pro'?'0 4px 20px rgba(47,145,239,0.15)':'none',
            flexShrink:0,
          }}>
            {plan.badge && (
              <div style={{position:'absolute',top:-12,left:'50%',transform:'translateX(-50%)',
                background:plan.color,color:'#fff',fontSize:10,fontWeight:700,
                padding:'3px 10px',borderRadius:20,whiteSpace:'nowrap'}}>
                {plan.badge}
              </div>
            )}
            <div style={{fontSize:13,fontWeight:700,color:plan.color,marginBottom:6}}>{plan.name}</div>
            <div style={{marginBottom:12}}>
              <span style={{fontSize:28,fontWeight:900,color:'#000'}}>${plan.price}</span>
              <span style={{fontSize:12,color:'#888'}}>{plan.period}</span>
            </div>
            <div style={{marginBottom:16,display:'flex',flexDirection:'column',gap:6}}>
              {plan.features.map(f=>(
                <div key={f} style={{fontSize:11,color:'#444',display:'flex',gap:5,alignItems:'flex-start'}}>
                  <span style={{color:plan.color,flexShrink:0,marginTop:1}}>✓</span>
                  <span>{f}</span>
                </div>
              ))}
            </div>
            <button onClick={()=>handleCTA(plan)} disabled={plan.disabled}
              style={{width:'100%',padding:'8px',fontSize:12,fontWeight:700,
                background:plan.disabled?'#f0f0f0':plan.color,
                color:plan.disabled?'#aaa':'#fff',
                border:`1px solid ${plan.disabled?'#ddd':plan.color}`,
                borderRadius:4,cursor:plan.disabled?'default':'pointer',
                fontFamily:C.fnt}}>
              {plan.cta}
            </button>
          </div>
        ))}
      </div>

      {/* Feature comparison */}
      <div style={{marginBottom:24}}>
        <div style={{fontSize:13,fontWeight:700,color:'#000',fontFamily:C.fnt,marginBottom:8}}>
          Full Feature Comparison
        </div>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:11,fontFamily:C.fnt}}>
          <thead>
            <tr style={{background:'#f5f7fa'}}>
              <th style={{padding:'8px',textAlign:'left',border:bd,fontWeight:700}}>Feature</th>
              {PLANS.map(p=><th key={p.name} style={{padding:'8px',textAlign:'center',border:bd,color:p.color,fontWeight:700}}>{p.name}</th>)}
            </tr>
          </thead>
          <tbody>
            {[
              ['Real-time quotes',        '15-min delay','✓','✓','✓'],
              ['Screener',                'Basic','Full','Full','Full'],
              ['Backtester',              '—','✓','✓','✓'],
              ['Pattern detection',       '—','✓','✓','✓'],
              ['Portfolio sync',          'Browser only','Supabase','Supabase','Supabase'],
              ['Forex & Futures',         '✓','✓','✓','✓'],
              ['Insider data',            '—','✓','✓','✓'],
              ['CSV export',              '—','—','✓','✓'],
              ['Team members',            '1','1','1','5'],
              ['API access',              '—','—','Soon','Soon'],
            ].map(([feat,...vals])=>(
              <tr key={feat}>
                <td style={{padding:'6px 8px',border:bd,color:'#555'}}>{feat}</td>
                {vals.map((v,i)=>(
                  <td key={i} style={{padding:'6px 8px',border:bd,textAlign:'center',
                    color:v==='✓'?C.pos:v==='—'?'#ccc':'#333',
                    fontWeight:v==='✓'?700:400}}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* FAQ */}
      <div>
        <div style={{fontSize:13,fontWeight:700,color:'#000',fontFamily:C.fnt,marginBottom:8}}>FAQ</div>
        {FAQ.map((f,i)=>(
          <div key={i} style={{border:bd,borderRadius:4,marginBottom:4,overflow:'hidden'}}>
            <div onClick={()=>setFaqOpen(p=>({...p,[i]:!p[i]}))}
              style={{padding:'10px 12px',cursor:'pointer',fontWeight:600,fontSize:12,
                fontFamily:C.fnt,background:faqOpen[i]?'#f0f4ff':'#fff',
                display:'flex',justifyContent:'space-between',userSelect:'none'}}>
              {f.q}
              <span style={{color:C.link}}>{faqOpen[i]?'−':'+'}</span>
            </div>
            {faqOpen[i] && (
              <div style={{padding:'8px 12px',fontSize:11,color:'#555',fontFamily:C.fnt,background:'#fafafa'}}>
                {f.a}
              </div>
            )}
          </div>
        ))}
      </div>

      <div style={{marginTop:16,fontSize:10,color:'#bbb',fontFamily:C.fnt,textAlign:'center'}}>
        CompoundPulse · Market data for informational purposes only · Not financial advice
        <br/>Prices subject to change · Stripe-secured payments
      </div>
    </div>
  )
}