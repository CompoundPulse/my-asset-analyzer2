'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'
import { Spark } from './dashAtoms'

function FutRow({ r, i }) {
  const [hov, setHov] = useState(false)
  const pos  = r.changePercent == null || parseFloat(r.changePercent) >= 0
  const seed = r.name.charCodeAt(0)*3 + i*7
  const fmtPrice = v => {
    if (v == null) return '…'
    const n = parseFloat(v)
    // Commodities show full price, ETFs show 2 decimals
    return `$${n.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}`
  }

  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'5px 8px',borderBottom:bd,fontWeight:600,color:C.link}}>
        {r.name}
        <span style={{color:'#bbb',fontSize:10,fontWeight:400,marginLeft:4}}>{r.label}</span>
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:700,color:'#000',
        fontFamily:'monospace',fontSize:13,whiteSpace:'nowrap'}}>
        {r.price != null ? fmtPrice(r.price) : <span style={{color:'#ddd'}}>…</span>}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:700,
        color:pos?C.pos:C.neg,whiteSpace:'nowrap'}}>
        {r.changePercent != null
          ? `${pos?'+':''}${parseFloat(r.changePercent).toFixed(2)}%`
          : <span style={{color:'#ddd'}}>…</span>}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right'}}>
        {r.price != null && <Spark pos={pos} seed={seed}/>}
      </td>
    </tr>
  )
}

export default function PageFutures() {
  const [data,    setData]    = useState([])
  const [loading, setLoading] = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    fetch('/api/futures-rates')
      .then(r => r.ok ? r.json() : [])
      .then(d => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Futures</span>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>
          {loading ? 'Loading…' : 'Gold/Silver/Oil: OANDA · Indices: ETF proxies · cached 15min'}
        </span>
      </div>
      {loading && <div style={{padding:40,textAlign:'center',color:C.txt}}>Loading…</div>}
      {!loading && (
        <>
          <table style={{width:'100%',maxWidth:500,borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
            <thead><tr>
              <th style={thS()}>Contract</th>
              <th style={thS(true)}>Last</th>
              <th style={thS(true)}>Change</th>
              <th style={thS(true)}>Daily</th>
            </tr></thead>
            <tbody>
              {data.length === 0
                ? <tr><td colSpan={4} style={{padding:20,textAlign:'center',color:'#aaa'}}>No data</td></tr>
                : data.map((r,i) => <FutRow key={r.name} r={r} i={i}/>)
              }
            </tbody>
          </table>
          <div style={{marginTop:6,fontSize:10,color:'#bbb',fontFamily:C.fnt}}>
            Commodities via OANDA real rates · Index contracts use ETF proxy prices (SPY, QQQ, DIA)
          </div>
        </>
      )}
    </div>
  )
}