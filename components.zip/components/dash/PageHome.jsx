'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'
import { SIG_L_TICKERS, SIG_R_TICKERS, RECENT_Q } from './dashData'
import { Spark } from './dashAtoms'

const fmtP = v => v != null ? `$${parseFloat(v).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}` : '—'
const fmtC = v => v != null ? `${parseFloat(v)>=0?'+':''}${parseFloat(v).toFixed(2)}%` : '—'
const fmtV = v => {
  if (!v) return '—'
  const n = parseFloat(v)
  if (n>=1e9) return (n/1e9).toFixed(1)+'B'
  if (n>=1e6) return (n/1e6).toFixed(1)+'M'
  if (n>=1e3) return (n/1e3).toFixed(0)+'K'
  return String(n)
}

function SigRow({ ticker, signal, i, q, onT }) {
  const [hov, setHov] = useState(false)
  const pos  = q?.changePercent == null || parseFloat(q.changePercent) >= 0
  const seed = ticker.charCodeAt(0)*7 + i*3
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      onClick={()=>onT(ticker)}>
      <td style={{padding:'3px 4px 3px 6px',borderBottom:bd}}>
        <span style={{color:C.link,fontWeight:700,fontSize:12}}>{ticker}</span>
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,fontSize:12,color:'#000',whiteSpace:'nowrap'}}>
        {q ? fmtP(q.price) : <span style={{color:'#ddd',fontSize:10}}>…</span>}
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,fontSize:12,color:pos?C.pos:C.neg,whiteSpace:'nowrap'}}>
        {q ? fmtC(q.changePercent) : <span style={{color:'#ddd',fontSize:10}}>…</span>}
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,textAlign:'right',fontSize:11,color:C.txt,whiteSpace:'nowrap'}}>
        {q ? fmtV(q.volume) : <span style={{color:'#ddd',fontSize:10}}>…</span>}
      </td>
      <td style={{width:4,borderBottom:bd}}/>
      <td style={{padding:'3px 6px',borderBottom:bd,width:'35%',whiteSpace:'nowrap'}}>
        <span style={{color:C.link,fontSize:11,marginRight:6}}>{signal}</span>
        {q && <Spark pos={pos} seed={seed}/>}
      </td>
    </tr>
  )
}

const SigHead = () => (
  <thead><tr>
    <th style={thS()}>Ticker</th>
    <th style={thS(true)}>Last</th>
    <th style={thS(true)}>Change</th>
    <th style={thS(true)}>Volume</th>
    <th style={{width:4,background:C.thBg,borderBottom:`1px solid ${C.thBdr}`}}/>
    <th style={{...thS(),width:'35%'}}>Signal</th>
  </tr></thead>
)

function IndexCard({ label, q }) {
  const price = q?.price
  const chg   = q?.changePercent
  const pos   = chg == null || parseFloat(chg) >= 0
  return (
    <div style={{textAlign:'center',lineHeight:'15px',fontFamily:'Verdana,Arial',fontSize:10}}>
      <div style={{fontWeight:700,color:C.txt}}>{label}</div>
      <div style={{fontWeight:700,color:'#000',fontSize:12}}>
        {price ? parseFloat(price).toLocaleString('en-US',{maximumFractionDigits:2}) : '…'}
      </div>
      <div style={{fontWeight:700,color:pos?C.pos:C.neg,fontSize:11}}>
        {chg != null ? fmtC(chg) : '…'}
      </div>
    </div>
  )
}

function NewsRow({ r, i, onT }) {
  const [hov, setHov] = useState(false)
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'3px 8px',borderBottom:bd,whiteSpace:'nowrap',verticalAlign:'top',width:55}}>
        {r.t && <span style={{color:C.link,fontWeight:700,fontSize:12,cursor:'pointer'}}
          onClick={()=>onT(r.t)}>{r.t}</span>}
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,verticalAlign:'top'}}>
        <a href={r.url} target="_blank" rel="noopener noreferrer"
          style={{color:'#333',textDecoration:'none',fontSize:12,lineHeight:'16px'}}
          onMouseEnter={e=>e.currentTarget.style.textDecoration='underline'}
          onMouseLeave={e=>e.currentTarget.style.textDecoration='none'}>
          {r.h}
        </a>
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11,color:'#888',textAlign:'right',verticalAlign:'top'}}>{r.src}</td>
      <td style={{padding:'3px 6px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11,color:'#888',textAlign:'right',verticalAlign:'top'}}>{r.time}</td>
    </tr>
  )
}

// Real screener rows — derived from live quotes, sorted by changePercent
function ScRow({ r, i, label, onT }) {
  const [hov, setHov] = useState(false)
  const pos = parseFloat(r.changePercent) >= 0
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      onClick={()=>onT(r.t)}>
      <td style={{padding:'3px 4px 3px 6px',borderBottom:bd}}>
        <span style={{color:C.link,fontWeight:700,fontSize:12}}>{r.t}</span>
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,fontSize:12,color:'#000',whiteSpace:'nowrap'}}>
        {fmtP(r.price)}
      </td>
      <td style={{padding:'3px 8px',borderBottom:bd,textAlign:'right',fontWeight:700,fontSize:12,color:pos?C.pos:C.neg,whiteSpace:'nowrap'}}>
        {fmtC(r.changePercent)}
      </td>
      <td style={{padding:'3px 6px',borderBottom:bd,whiteSpace:'nowrap'}}>
        <span style={{color:C.link,fontSize:11}}>{label}</span>
        <Spark pos={pos} seed={r.t.charCodeAt(0)*3+i}/>
      </td>
    </tr>
  )
}

const ScHead = () => (
  <thead><tr>
    <th style={thS()}>Ticker</th>
    <th style={thS(true)}>Last</th>
    <th style={thS(true)}>Change</th>
    <th style={thS()}>Category</th>
  </tr></thead>
)

// Derive real screener lists from quotes
function buildScreener(quotes) {
  const SCREENER_TICKERS = [
    'NVDA','AMD','META','GOOGL','AMZN','TSLA','AAPL','MSFT','LLY','V','MA',
    'COST','HD','NKE','BA','PFE','T','WBA','VZ','CVS','INTC','DIS','XOM','CVX',
    'ARKK','TQQQ','IWM','GLD','TLT','F','JPM','WMT','NFLX','SOXS','CSGP','SPY','QQQ'
  ]
  const rows = SCREENER_TICKERS
    .filter(t => quotes[t]?.price != null)
    .map(t => ({ t, ...quotes[t] }))
    .sort((a,b) => parseFloat(b.changePercent) - parseFloat(a.changePercent))

  const gainers   = rows.slice(0, 7).map(r => ({ ...r, label: 'Top Gainers' }))
  const losers    = rows.slice(-7).reverse().map(r => ({ ...r, label: 'Top Losers' }))
  const active    = [...rows].sort((a,b) => (b.volume||0)-(a.volume||0)).slice(0,4).map(r=>({...r,label:'Most Active'}))
  const volatile  = rows.filter(r => Math.abs(parseFloat(r.changePercent))>1).slice(0,3).map(r=>({...r,label:'Volatile'}))

  return { gainers, losers, active, volatile }
}

function EarnRow({ e, ri, onT }) {
  const [hov, setHov] = useState(false)
  return (
    <tr style={{background:hov?C.hov:ri%2?C.alt:'#fff'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'3px 8px',borderBottom:bd,fontSize:12,whiteSpace:'nowrap',color:C.link,fontWeight:600}}>{e.d}</td>
      {e.tt.map((t,ti)=>(
        <td key={ti} style={{padding:'3px 4px',borderBottom:bd,fontSize:12}}>
          <span style={{color:C.link,fontWeight:600,cursor:'pointer'}} onClick={()=>onT(t)}>{t}</span>
        </td>
      ))}
      {Array.from({length:Math.max(0,8-e.tt.length)}).map((_,pi)=>(
        <td key={'p'+pi} style={{padding:'3px 4px',borderBottom:bd}}>&nbsp;</td>
      ))}
    </tr>
  )
}

export default function PageHome({ onT }) {
  const [quotes,   setQuotes]   = useState({})
  const [news,     setNews]     = useState([])
  const [earnings, setEarnings] = useState([])
  const [loading,  setLoading]  = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    // Single call — all data, all cached in Supabase
    fetch('/api/market-data?section=all')
      .then(r => r.ok ? r.json() : {})
      .then(d => {
        if (d.quotes)   setQuotes(d.quotes)
        if (d.news)     setNews(d.news)
        if (d.earnings) setEarnings(d.earnings)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const q = quotes
  const { gainers, losers, active, volatile } = loading ? {gainers:[],losers:[],active:[],volatile:[]} : buildScreener(q)
  const leftRows  = [...gainers, ...active, ...volatile].slice(0, 18)
  const rightRows = [...losers,  ...active.slice(2)].slice(0, 17)
  const tbl = {width:'100%',borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}

  return (
    <>
      {/* Breadth + index cards */}
      <div style={{display:'flex',alignItems:'flex-start',margin:'4px 0',borderBottom:'1px solid #e8e8e8',paddingBottom:6}}>
        {[
          {l:'Advancing',r:'Declining', lp:50.6},
          {l:'New High',  r:'New Low',  lp:52.1},
          {l:'Above SMA50',r:'Below',   lp:49.6},
          {l:'Above SMA200',r:'Below',  lp:51.9},
        ].map((b,i)=>(
          <div key={i} style={{flex:1,padding:'4px 6px',fontFamily:'Verdana,Arial',fontSize:9}}>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
              <span style={{fontWeight:700,color:C.pos}}>{b.l}</span>
              <span style={{fontWeight:700,color:C.neg}}>{b.r}</span>
            </div>
            <div style={{display:'flex',height:8,borderRadius:1,overflow:'hidden'}}>
              <div style={{width:`${b.lp}%`,background:C.pos}}/>
              <div style={{flex:1,background:C.neg}}/>
            </div>
          </div>
        ))}
        <div style={{flex:1,display:'flex',justifyContent:'center',gap:16,padding:'2px 8px',flexWrap:'wrap'}}>
          <IndexCard label="S&P 500" q={q['SPY']}/>
          <IndexCard label="NASDAQ"  q={q['QQQ']}/>
          <IndexCard label="DOW"     q={q['DIA']}/>
          <IndexCard label="GOLD"    q={q['GLD']}/>
        </div>
      </div>

      {loading && (
        <div style={{padding:40,textAlign:'center',color:C.txt,fontSize:13,fontFamily:C.fnt}}>
          Loading market data…
        </div>
      )}

      {!loading && (
        <>
          {/* Live Screener tables — real data sorted by changePercent */}
          <table width="100%" cellPadding="0" cellSpacing="0" border="0" style={{tableLayout:'fixed',marginTop:4}}>
            <tbody><tr>
              <td width="50%" style={{verticalAlign:'top'}}>
                <table style={tbl}><ScHead/>
                  <tbody>{leftRows.map((r,i)=><ScRow key={r.t+i} r={r} i={i} label={r.label} onT={onT}/>)}</tbody>
                </table>
              </td>
              <td style={{width:16}}/>
              <td width="50%" style={{verticalAlign:'top'}}>
                <table style={tbl}><ScHead/>
                  <tbody>{rightRows.map((r,i)=><ScRow key={r.t+i} r={r} i={i} label={r.label} onT={onT}/>)}</tbody>
                </table>
              </td>
            </tr></tbody>
          </table>

          <div style={{height:10}}/>

          {/* Real News + Recent Quotes */}
          <table width="100%" cellPadding="0" cellSpacing="0" border="0">
            <tbody><tr>
              <td style={{verticalAlign:'top'}}>
                <table style={tbl}>
                  <thead><tr>
                    <th colSpan={4} style={{padding:'5px 8px',background:C.hdrBg,textAlign:'left',borderRadius:'3px 3px 0 0'}}>
                      <b style={{color:'#fff',fontSize:12}}>Market News</b>
                      <span style={{color:'#8cb8d8',fontSize:10,fontWeight:400,marginLeft:8}}>live · Finnhub</span>
                    </th>
                  </tr></thead>
                  <tbody>
                    {news.length === 0 && <tr><td colSpan={4} style={{padding:'16px 8px',color:C.txt,textAlign:'center'}}>No news</td></tr>}
                    {news.map((r,i)=><NewsRow key={i} r={r} i={i} onT={onT}/>)}
                  </tbody>
                </table>
              </td>
              <td style={{width:6}}/>
              <td style={{width:280,verticalAlign:'top'}}>
                <table style={tbl}>
                  <thead><tr>
                    <th style={{padding:'4px 8px',background:C.hdrBg,textAlign:'left',borderRadius:'3px 0 0 0'}}>
                      <b style={{color:'#fff',fontSize:12}}>Recent Quotes</b>
                    </th>
                    <th style={{padding:'4px 8px',background:C.hdrBg,color:'#acaeb3',fontSize:11,fontWeight:600,borderRadius:'0 3px 0 0'}}>Signal</th>
                  </tr></thead>
                  <tbody>{RECENT_Q.map((r,i)=>(
                    <tr key={i} style={{background:i%2?C.alt:'#fff',cursor:'pointer'}} onClick={()=>onT(r.t)}>
                      <td style={{padding:'3px 8px',borderBottom:bd,fontSize:12}}>
                        <span style={{color:C.link,fontWeight:600}}>{r.t}</span>
                      </td>
                      <td style={{padding:'3px 8px',borderBottom:bd,fontSize:11,color:C.link}}>{r.s}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </td>
            </tr></tbody>
          </table>

          <div style={{height:10}}/>

          {/* Real Earnings Calendar */}
          {earnings.length > 0 && (
            <table style={tbl}>
              <thead><tr>
                <th style={{...thS(),width:'14%',whiteSpace:'nowrap'}}>Earnings Date</th>
                <th colSpan={8} style={thS()}>Companies Reporting</th>
              </tr></thead>
              <tbody>{earnings.map((e,ri)=>(
                <EarnRow key={ri} e={e} ri={ri} onT={onT}/>
              ))}</tbody>
            </table>
          )}
          <div style={{height:24}}/>
        </>
      )}
    </>
  )
}