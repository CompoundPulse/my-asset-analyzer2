// PageCrypto.jsx — live crypto from KuCoin API
'use client'
import { useState, useEffect } from 'react'
import { C, bd, thS } from './dashTheme'
import { CRYPTO_SYMBOLS, CRYPTO_NAMES } from './dashData'
import { Spark } from './dashAtoms'

function CryptoRow({ t, i, onT }) {
  const [data, setData] = useState(null)
  const [hov, setHov] = useState(false)
  const seed = t.charCodeAt(0)*3+i*7

  useEffect(() => {
    fetch(`/api/crypto?symbol=${t}&type=ticker`)
      .then(r=>r.ok?r.json():null)
      .then(d=>setData(d))
      .catch(()=>{})
  }, [t])

  const price = data?.price ? parseFloat(data.price) : null
  const chgPct = data?.changePercent ?? null
  const pos = chgPct == null || chgPct >= 0

  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'6px 8px',borderBottom:bd,fontWeight:700}}>
        <a style={{color:C.link,textDecoration:'none',fontWeight:700}} href="#"
          onClick={e=>{e.preventDefault();onT(t)}}>{t}</a>
      </td>
      <td style={{padding:'6px 8px',borderBottom:bd,color:C.txt,fontSize:12}}>{CRYPTO_NAMES[t]}</td>
      <td style={{padding:'6px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,color:'#000',whiteSpace:'nowrap',fontFamily:'monospace,Lato'}}>
        {price!=null ? `$${price.toLocaleString('en-US',{minimumFractionDigits:price>10?2:4,maximumFractionDigits:price>10?2:6})}` : <span style={{color:'#bbb',fontSize:11}}>loading…</span>}
      </td>
      <td style={{padding:'6px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,whiteSpace:'nowrap',color:pos?C.pos:C.neg}}>
        {chgPct!=null ? `${chgPct>=0?'+':''}${chgPct.toFixed(2)}%` : <span style={{color:'#bbb',fontSize:11}}>—</span>}
      </td>
      <td style={{padding:'6px 8px',borderBottom:bd,textAlign:'right'}}>
        {data ? <Spark pos={pos} seed={seed}/> : <span style={{color:'#ddd',fontSize:11}}>—</span>}
      </td>
    </tr>
  )
}

export default function PageCrypto({ onT }) {
  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Crypto Markets</span>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>Live prices via KuCoin</span>
      </div>
      <table style={{width:'100%',maxWidth:700,borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
        <thead><tr>
          <th style={thS(false)}>Symbol</th>
          <th style={thS(false)}>Name</th>
          <th style={thS(true)}>Price (USD)</th>
          <th style={thS(true)}>24h Change</th>
          <th style={thS(true)}>Daily</th>
        </tr></thead>
        <tbody>
          {CRYPTO_SYMBOLS.map((t,i)=><CryptoRow key={t} t={t} i={i} onT={onT}/>)}
        </tbody>
      </table>
    </div>
  )
}
