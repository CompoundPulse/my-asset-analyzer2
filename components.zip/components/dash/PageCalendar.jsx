'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'

export default function PageCalendar({ onT }) {
  const [earnings, setEarnings] = useState([])
  const [econ,     setEcon]     = useState([])
  const [loading,  setLoading]  = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    Promise.all([
      fetch('/api/market-data?section=earnings').then(r=>r.ok?r.json():[]),
      fetch('/api/econ-calendar').then(r=>r.ok?r.json():[]),
    ]).then(([earn,eco]) => { setEarnings(earn); setEcon(eco); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const tbl = {width:'100%',borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}
  const impColor = i => i==='Hi'?'#d93025':i==='Med'?'#f59e0b':'#888'

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>
        Economic & Earnings Calendar
        <span style={{fontSize:11,color:C.txt,fontWeight:400,marginLeft:8}}>Finnhub · cached 4hr</span>
      </div>
      {loading && <div style={{padding:40,textAlign:'center',color:C.txt}}>Loading calendars…</div>}
      {!loading && (
        <table width="100%" cellPadding="0" cellSpacing="0" border="0">
          <tbody><tr>
            <td style={{width:'50%',verticalAlign:'top',paddingRight:8}}>
              <table style={tbl}>
                <thead><tr>
                  <th style={thS()}>Date</th><th style={thS()}>Time</th>
                  <th style={thS()}>Imp</th><th style={thS()}>Release</th>
                  <th style={thS(true)}>Est.</th><th style={thS(true)}>Prior</th>
                </tr></thead>
                <tbody>
                  {econ.length===0 && <tr><td colSpan={6} style={{padding:20,textAlign:'center',color:'#aaa',fontSize:11}}>Economic events limited on Finnhub free tier · <a href="https://tradingeconomics.com/calendar" target="_blank" rel="noopener noreferrer" style={{color:'#2f91ef'}}>View full calendar →</a></td></tr>}
                  {econ.map((e,i)=>(
                    <tr key={i} style={{background:i%2?C.alt:'#fff'}}>
                      <td style={{padding:'4px 8px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11}}>{e.d}</td>
                      <td style={{padding:'4px 8px',borderBottom:bd,whiteSpace:'nowrap',fontSize:11}}>{e.t}</td>
                      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'center'}}>
                        <span style={{fontSize:10,fontWeight:700,color:impColor(e.imp),
                          background:e.imp==='Hi'?'#fde8e8':e.imp==='Med'?'#fef3c7':'#f5f5f5',
                          padding:'1px 5px',borderRadius:2}}>{e.imp}</span>
                      </td>
                      <td style={{padding:'4px 8px',borderBottom:bd,fontSize:11,color:C.txt}}>{e.r}</td>
                      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'right',fontSize:11}}>{e.e}</td>
                      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'right',fontSize:11,color:'#888'}}>{e.p}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </td>
            <td style={{width:'50%',verticalAlign:'top',paddingLeft:8}}>
              <table style={tbl}>
                <thead><tr>
                  <th style={thS()}>Date</th>
                  <th style={thS()}>Companies Reporting</th>
                </tr></thead>
                <tbody>
                  {earnings.length===0 && <tr><td colSpan={2} style={{padding:20,textAlign:'center',color:C.txt}}>No upcoming earnings</td></tr>}
                  {earnings.map((e,i)=>(
                    <tr key={i} style={{background:i%2?C.alt:'#fff',verticalAlign:'top'}}>
                      <td style={{padding:'4px 8px',borderBottom:bd,whiteSpace:'nowrap',fontSize:12,fontWeight:600}}>{e.d}</td>
                      <td style={{padding:'4px 8px',borderBottom:bd,fontSize:12}}>
                        <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
                          {e.tt.map((t,ti)=>(
                            <span key={ti} style={{color:C.link,fontWeight:600,cursor:'pointer'}} onClick={()=>onT(t)}>{t}</span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </td>
          </tr></tbody>
        </table>
      )}
    </div>
  )
}