'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'
import { Spark } from './dashAtoms'

// Sector ETFs - prices fetched live via cache
const SECTORS = [
  { name:'Technology',       etf:'XLK',  desc:'NVDA AAPL MSFT GOOGL META' },
  { name:'Healthcare',       etf:'XLV',  desc:'LLY JNJ UNH ABBV MRK' },
  { name:'Financials',       etf:'XLF',  desc:'JPM BAC WFC GS MS' },
  { name:'Consumer Cyc.',    etf:'XLY',  desc:'AMZN TSLA HD NKE MCD' },
  { name:'Communication',    etf:'XLC',  desc:'GOOGL META NFLX DIS T' },
  { name:'Industrials',      etf:'XLI',  desc:'GE HON CAT BA RTX' },
  { name:'Energy',           etf:'XLE',  desc:'XOM CVX COP SLB OXY' },
  { name:'Consumer Def.',    etf:'XLP',  desc:'WMT PG KO PEP COST' },
  { name:'Real Estate',      etf:'XLRE', desc:'PLD AMT EQIX SPG O' },
  { name:'Utilities',        etf:'XLU',  desc:'NEE DUK SO AEP XEL' },
  { name:'Materials',        etf:'XLB',  desc:'LIN APD ECL SHW FCX' },
]

function GRow({ r, i, q }) {
  const [hov, setHov] = useState(false)
  const chg = q?.changePercent
  const pos = chg == null || parseFloat(chg) >= 0
  const seed = r.name.charCodeAt(0)*3 + i*7
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'5px 8px',borderBottom:bd,fontSize:12,fontWeight:600,color:C.link}}>{r.name}</td>
      <td style={{padding:'5px 8px',borderBottom:bd,fontSize:11,color:'#888'}}>{r.etf}</td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:700,
        color:pos?C.pos:C.neg,whiteSpace:'nowrap'}}>
        {chg != null
          ? `${pos?'+':''}${parseFloat(chg).toFixed(2)}%`
          : <span style={{color:'#ccc',fontSize:10}}>…</span>}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,color:'#000'}}>
        {q?.price != null ? `$${parseFloat(q.price).toFixed(2)}` : '—'}
      </td>
      <td style={{padding:'5px 8px',borderBottom:bd,fontSize:11,color:'#aaa'}}>{r.desc}</td>
      <td style={{padding:'5px 8px',borderBottom:bd,textAlign:'right'}}>
        {q && <Spark pos={pos} seed={seed}/>}
      </td>
    </tr>
  )
}

export default function PageGroups() {
  const [quotes, setQuotes] = useState({})
  const [loading, setLoading] = useState(true)
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    const syms = SECTORS.map(s => s.etf).join(',')
    const load = () => fetch(`/api/batch-quotes?symbols=${syms}`)
      .then(r => r.ok ? r.json() : {})
      .then(d => {
        setLoading(false)
        if (Object.keys(d).length > 0) { setQuotes(d) }
        else { setTimeout(load, 2500) } // retry if cache cold
      })
      .catch(() => setLoading(false))
    load()
  }, [])

  // Sort by change desc
  const sorted = [...SECTORS].sort((a,b) => {
    const ca = parseFloat(quotes[a.etf]?.changePercent ?? 0)
    const cb = parseFloat(quotes[b.etf]?.changePercent ?? 0)
    return cb - ca
  })

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Sector Groups</span>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>
          {loading ? 'Loading live ETF prices…' : 'Live ETF prices · Finnhub · cached 15min'}
        </span>
      </div>
      <table style={{width:'100%',maxWidth:900,borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
        <thead><tr>
          <th style={thS()}>Sector</th>
          <th style={thS()}>ETF</th>
          <th style={thS(true)}>Change</th>
          <th style={thS(true)}>Price</th>
          <th style={thS()}>Top Holdings</th>
          <th style={thS(true)}>Daily</th>
        </tr></thead>
        <tbody>
          {sorted.map((r,i) => <GRow key={r.etf} r={r} i={i} q={quotes[r.etf]}/>)}
        </tbody>
      </table>
      <div style={{marginTop:6,fontSize:10,color:'#bbb',fontFamily:C.fnt}}>
        Sector performance via ETF proxies · Stock counts and market caps require premium data
      </div>
    </div>
  )
}