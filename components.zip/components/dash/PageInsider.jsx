'use client'
import { useState, useEffect, useRef } from 'react'
import { C, bd, thS } from './dashTheme'

const FILTERS = ['All','Purchase','Sale']

function InsiderRow({ r, i, onT }) {
  const [hov, setHov] = useState(false)
  return (
    <tr style={{background:hov?C.hov:i%2?C.alt:'#fff',cursor:'pointer'}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}>
      <td style={{padding:'4px 8px',borderBottom:bd}}>
        <span style={{color:C.link,fontWeight:700,cursor:'pointer'}} onClick={()=>onT(r.t)}>{r.t}</span>
      </td>
      <td style={{padding:'4px 8px',borderBottom:bd,color:C.txt}}>{r.name}</td>
      <td style={{padding:'4px 8px',borderBottom:bd,color:C.txt,fontSize:11}}>{r.role}</td>
      <td style={{padding:'4px 8px',borderBottom:bd,fontWeight:700,color:r.type==='Purchase'?C.pos:C.neg}}>{r.type}</td>
      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'right',color:C.txt}}>{r.shares}</td>
      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'right',fontWeight:600,color:'#000'}}>{r.val}</td>
      <td style={{padding:'4px 8px',borderBottom:bd,textAlign:'right',color:C.txt,whiteSpace:'nowrap'}}>{r.date}</td>
      <td style={{padding:'4px 8px',borderBottom:bd}}>
        <a href={r.url} target="_blank" rel="noopener noreferrer" style={{color:C.link,fontSize:11,textDecoration:'none'}}>SEC ↗</a>
      </td>
    </tr>
  )
}

export default function PageInsider({ onT }) {
  const [trades, setTrades] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('All')
  const fetched = useRef(false)

  useEffect(() => {
    if (fetched.current) return
    fetched.current = true
    fetch('/api/market-data?section=insider')
      .then(r => r.ok ? r.json() : [])
      .then(data => { setTrades(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const rows = filter === 'All' ? trades : trades.filter(r => r.type === filter)

  return (
    <div style={{padding:'12px 0'}}>
      <div style={{marginBottom:10,display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
        <span style={{fontSize:15,fontWeight:700,color:'#000',fontFamily:C.fnt}}>Insider Trading</span>
        <div style={{display:'flex',gap:4}}>
          {FILTERS.map(f=>(
            <button key={f} onClick={()=>setFilter(f)} style={{
              padding:'3px 10px',fontSize:11,borderRadius:3,cursor:'pointer',
              border:`1px solid ${filter===f?C.link:'#ccc'}`,
              background:filter===f?C.link:'#fff',
              color:filter===f?'#fff':C.txt,
              fontFamily:C.fnt,fontWeight:600,
            }}>{f}</button>
          ))}
        </div>
        <span style={{fontSize:11,color:C.txt,fontFamily:C.fnt}}>
          {loading ? 'Loading SEC filings…' : `${rows.length} transactions · SEC Form 4 · cached 4hr`}
        </span>
      </div>
      {loading && <div style={{padding:40,textAlign:'center',color:C.txt}}>Loading…</div>}
      {!loading && (
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:12,fontFamily:C.fnt}}>
          <thead><tr>
            <th style={thS()}>Ticker</th><th style={thS()}>Insider</th>
            <th style={thS()}>Role</th><th style={thS()}>Type</th>
            <th style={thS(true)}>Shares</th><th style={thS(true)}>Value</th>
            <th style={thS(true)}>Date</th><th style={thS()}>Filing</th>
          </tr></thead>
          <tbody>
            {rows.length===0 && <tr><td colSpan={8} style={{padding:20,textAlign:'center',color:C.txt}}>No data</td></tr>}
            {rows.map((r,i)=><InsiderRow key={i} r={r} i={i} onT={onT}/>)}
          </tbody>
        </table>
      )}
    </div>
  )
}